#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math, json, re, time, threading
from typing import List, Dict, Optional, Tuple

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from rclpy.callback_groups import ReentrantCallbackGroup

from std_msgs.msg import String
from moveit_msgs.action import MoveGroup
from moveit_msgs.msg import MotionPlanRequest, Constraints, JointConstraint


def deg(d: float) -> float:
    return d * math.pi / 180.0


class HSPickCarry(Node):
    """Auto pick → lift → carry for each new box event seen on /hmi/unified_status."""

    # ---- Robot / MoveIt config ----
    JOINT_NAMES: List[str]   = ['joint_1','joint_2','joint_3','joint_4','joint_5','joint_6']
    PLANNING_GROUP: str      = 'tmr_arm'

    # ---- Timing / reliability knobs ----
    MIN_TRIGGER_INTERVAL_S   = 2.0    # avoid hammering the action server
    STAGE_DELAY_S            = 0.40   # pause between PICK→LIFT→CARRY

    # Action timeouts / retries
    GOAL_SEND_TIMEOUT_S      = 10.0   # wait for ACCEPT (first goal can be slow)
    GOAL_RESULT_TIMEOUT_S    = 12.0   # wait for plan+execute result
    ACCEPT_RETRIES           = 2      # retry sends if accept times out
    ACCEPT_RETRY_BACKOFF_S   = 0.75   # small backoff between retries

    # ---- Pick poses (your known-good values) ----
    PICK_SMALL = [deg(29),  deg(39), deg(59), deg(1),  deg(92), deg(27)]
    PICK_MID   = [deg(1),   deg(31), deg(59), deg(6),  deg(91), deg(1)]
    PICK_BIG   = [deg(-31), deg(35), deg(49), deg(9),  deg(90), 0.0]

    # ---- Carry pose (your requested values) ----
    # (0°, 13°, 21°, 15°, 18°, 0°)
    CARRY      = [deg(0), deg(13), deg(21), deg(15), deg(18), deg(0)]

    POSE_BY_TYPE: Dict[str, List[float]] = {
        'small':  PICK_SMALL,
        'medium': PICK_MID,
        'mid':    PICK_MID,
        'big':    PICK_BIG,
        'large':  PICK_BIG,
    }

    def __init__(self):
        super().__init__('hs_auto_pick_carry')

        # Re-entrant callback group (actions+subs concurrently)
        self.cb_group = ReentrantCallbackGroup()

        # Optional override via params
        self.declare_parameter('action_name', '')
        self.declare_parameter('delay_between_lift_and_carry_s', 3.0)
        requested = self.get_parameter('action_name').get_parameter_value().string_value
        self.delay_between_lift_and_carry_s = float(
            self.get_parameter('delay_between_lift_and_carry_s').get_parameter_value().double_value
        )

        self.client, self.ACTION_NAME = self._connect_action(requested)

        # HMI subscriber
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=30,
        )
        self.sub = self.create_subscription(
            String, '/hmi/unified_status', self._status_cb, qos, callback_group=self.cb_group
        )

        # State
        self.busy: bool = False
        self.last_counts: Dict[str, int] = {'big': 0, 'medium': 0, 'small': 0}
        self.prev_present: bool = False
        self.last_trigger_time: float = 0.0

        self.get_logger().info('Listening for box events…')

    # ---- Action server auto-detect ----
    def _connect_action(self, requested: str):
        candidates = []
        if requested:
            candidates.append(requested)
        candidates += ['/move_group', '/move_action', 'move_group', 'move_action']

        for name in candidates:
            client = ActionClient(self, MoveGroup, name, callback_group=self.cb_group)
            self.get_logger().info(f'Waiting for MoveGroup action server at "{name}"…')
            if client.wait_for_server(timeout_sec=3.0):
                self.get_logger().info(f'✅ MoveGroup action server ready at "{name}".')
                return client, name
            else:
                self.get_logger().warn(f'No server at "{name}" (timeout). Trying next…')

        # fallback
        fallback = '/move_group'
        self.get_logger().error(
            f'❌ Could not find a MoveGroup action server on any known name. '
            f'Please start MoveIt2 or pass -p action_name:=<name>. Using "{fallback}" for now.'
        )
        client = ActionClient(self, MoveGroup, fallback, callback_group=self.cb_group)
        return client, fallback

    # -------------------- HMI callback --------------------
    def _status_cb(self, msg: String):
        if self.busy:
            return

        data = self._parse_status_json(msg.data)
        if not data:
            return

        counts = data.get('counts') or {}
        box    = data.get('box') or {}

        big = int(counts.get('big', 0))
        med = int(counts.get('medium', counts.get('mid', 0) or 0))
        sml = int(counts.get('small', 0))

        # --- FIX 1: normalize location; require real, non-empty location ---
        raw_loc = (box.get('location') or '-')
        loc = raw_loc.strip()               # handles '\n', '  A  ', etc.
        weight_ok = (self._parse_weight(box.get('weight_raw', '0')) > 0.0)
        present = weight_ok and (loc != '-') and (loc != '')
        # -------------------------------------------------------------------

        deltas = {
            'big':    big - self.last_counts.get('big', 0),
            'medium': med - self.last_counts.get('medium', 0),
            'small':  sml - self.last_counts.get('small', 0),
        }

        now = time.time()
        if now - self.last_trigger_time < self.MIN_TRIGGER_INTERVAL_S:
            self._update_trackers(big, med, sml, present)
            return

        # Choose box type: prefer the one whose count just increased; otherwise pick the max current
        chosen_type: Optional[str] = None
        if deltas['big'] > 0 or deltas['medium'] > 0 or deltas['small'] > 0:
            order = ['big', 'medium', 'small']
            chosen_type = max(order, key=lambda k: (deltas[k], {'big':2, 'medium':1, 'small':0}[k]))
        elif (present and not self.prev_present):
            order = [('big', big), ('medium', med), ('small', sml)]
            chosen_type = max(order, key=lambda kv: kv[1])[0]

        self._update_trackers(big, med, sml, present)
        if not chosen_type:
            return

        # prevent overlapping sequences by guarding before the delay
        self.busy = True
        self.get_logger().info(f'New {chosen_type} box detected — waiting 4.00s before pick sequence…')
        time.sleep(4.0)

        pick_pose = self._pose_for(chosen_type)
        if not pick_pose:
            self.get_logger().warn(f'No pose mapped for "{chosen_type}".')
            self.busy = False  # release guard if we cannot proceed
            return

        lift_pose = self._lift_from(pick_pose)
        carry_pose = self.CARRY
        carry_pose_alt = self._carry_with_wrist(pick_pose)

        # Defer execution to a worker thread
        self.busy = True
        self.get_logger().info(f'New {chosen_type} box detected (counts={counts}, box={box}). Scheduling pick→lift→carry.')
        t = threading.Thread(
            target=self._run_sequence,
            args=(chosen_type, pick_pose, lift_pose, carry_pose, carry_pose_alt),
            daemon=True
        )
        t.start()

    # -------------------- Worker that runs the motion sequence --------------------
    def _run_sequence(self, chosen_type: str, pick_pose: List[float],
                      lift_pose: List[float], carry_pose: List[float],
                      carry_pose_alt: List[float]):
        try:
            # 1) PICK
            self.get_logger().info('[PICK] planning…')
            if not self._go_to_async(pick_pose, tag='PICK'):
                self.get_logger().error('Pick pose failed; aborting.')
                self.last_trigger_time = time.time()
                return
            time.sleep(self.STAGE_DELAY_S)

            # 2) LIFT
            self.get_logger().info('[LIFT] planning…')
            if not self._go_to_async(lift_pose, tag='LIFT'):
                self.get_logger().warn('Lift failed; attempting to go straight to CARRY.')
            time.sleep(self.STAGE_DELAY_S)

            # Optional extra wait between lift and carry
            if self.delay_between_lift_and_carry_s > 0.0:
                self.get_logger().info(f'Waiting {self.delay_between_lift_and_carry_s:.2f}s before carry…')
                time.sleep(self.delay_between_lift_and_carry_s)

            # 3) CARRY
            self.get_logger().info('[CARRY] planning…')
            if self._go_to_async(carry_pose, tag='CARRY'):
                self.get_logger().info(f'✅ Completed {chosen_type} pick→carry.')
                self.last_trigger_time = time.time()
                return

            self.get_logger().warn('[CARRY] default failed; retrying with wrist preserved…')
            if self._go_to_async(carry_pose_alt, tag='CARRY_ALT_WRIST'):
                self.get_logger().info(f'✅ Completed {chosen_type} pick→carry (alt wrist).')
                self.last_trigger_time = time.time()
                return

            self.get_logger().error('Carry failed (default + alt).')
            self.last_trigger_time = time.time()
        finally:
            self.busy = False

    # -------------------- Helper functions --------------------
    def _lift_from(self, pick_pose: List[float]) -> List[float]:
        j = pick_pose.copy()
        j[1] = j[1] - deg(12)                               # shoulder a bit down
        j[2] = j[2] + deg(12)                               # elbow a bit up
        j[4] = min(max(j[4], deg(45)), deg(110))            # keep wrist-2 in strong range
        return self._clamp_joints(j)

    def _carry_with_wrist(self, pick_pose: List[float]) -> List[float]:
        c = self.CARRY.copy()
        c[-1] = pick_pose[-1]  # preserve wrist roll to avoid big spin
        return c

    def _clamp_joints(self, joints: List[float]) -> List[float]:
        out = []
        for a in joints:
            while a >  math.pi: a -= 2*math.pi
            while a < -math.pi: a += 2*math.pi
            out.append(a)
        return out

    def _update_trackers(self, big, med, sml, present):
        self.last_counts = {'big': big, 'medium': med, 'small': sml}
        self.prev_present = present

    def _pose_for(self, box_type: str) -> Optional[List[float]]:
        k = box_type.lower()
        if k in self.POSE_BY_TYPE: return self.POSE_BY_TYPE[k]
        if k.startswith('med'):    return self.POSE_BY_TYPE['medium']
        if k.startswith('sma'):    return self.POSE_BY_TYPE['small']
        if k.startswith('big'):    return self.POSE_BY_TYPE['big']
        if k.startswith('lar'):    return self.POSE_BY_TYPE['large']
        return None

    def _parse_status_json(self, text: str) -> Optional[Dict]:
        if not text:
            return None
        try:
            return json.loads(text)
        except Exception:
            pass
        m = re.search(r'(\{.*\})', text, flags=re.DOTALL)
        if not m:
            return None
        candidate = m.group(1)
        last_brace = candidate.rfind('}')
        if last_brace != -1:
            candidate = candidate[:last_brace+1]
        try:
            return json.loads(candidate)
        except Exception:
            self.get_logger().debug('Failed to parse unified_status payload.')
            return None

    def _parse_weight(self, raw: str) -> float:
        if not raw:
            return 0.0
        m = re.search(r'(-?\d+(?:\.\d+)?)', raw)
        return float(m.group(1)) if m else 0.0

    # -------------------- MoveIt plumbing (pure async with Events) --------------------
    def _goal_from_joints(self, joints: List[float]) -> MoveGroup.Goal:
        goal = MoveGroup.Goal()
        req = MotionPlanRequest()
        req.group_name = self.PLANNING_GROUP

        # Robust but not endless
        req.num_planning_attempts = 16
        req.allowed_planning_time = 5.0
        req.max_velocity_scaling_factor = 0.6
        req.max_acceleration_scaling_factor = 0.6

        cs = Constraints()
        for name, val in zip(self.JOINT_NAMES, joints):
            jc = JointConstraint()
            jc.joint_name = name
            jc.position = val
            jc.tolerance_above = 0.06   # ~3.4°
            jc.tolerance_below = 0.06
            jc.weight = 1.0
            cs.joint_constraints.append(jc)

        req.goal_constraints.append(cs)
        goal.request = req
        goal.planning_options.plan_only = False  # plan + execute
        return goal

    def _go_to_async(self, joints: List[float], tag: str = '') -> bool:
        joints = self._clamp_joints(joints)
        self.get_logger().info(f'[{tag}] Sending goal: { [round(math.degrees(j),1) for j in joints] }')

        # Events to wait on without spin_until_future_complete
        resp_event  = threading.Event()
        done_event  = threading.Event()
        store: Dict[str, object] = {'handle': None, 'accepted': False, 'result': None, 'status': None}

        def on_goal_response(fut):
            try:
                handle = fut.result()
            except Exception as e:
                self.get_logger().error(f'[{tag}] Goal response error: {e}')
                resp_event.set()
                return
            if handle and handle.accepted:
                store['handle'] = handle
                store['accepted'] = True
                # chain result
                res_fut = handle.get_result_async()
                res_fut.add_done_callback(on_result)
            else:
                self.get_logger().error(f'[{tag}] Goal rejected by MoveGroup.')
            resp_event.set()

        def on_result(fut):
            try:
                res = fut.result()
            except Exception as e:
                self.get_logger().error(f'[{tag}] Result callback error: {e}')
                done_event.set()
                return
            store['result'] = res
            try:
                store['status'] = res.status
            except Exception:
                store['status'] = None
            done_event.set()

        # Try to send with a couple of retries for ACCEPT
        for attempt in range(1, self.ACCEPT_RETRIES + 2):
            resp_event.clear()
            done_event.clear()
            try:
                fut = self.client.send_goal_async(self._goal_from_joints(joints))
                fut.add_done_callback(on_goal_response)
            except Exception as e:
                self.get_logger().error(f'[{tag}] send_goal_async threw: {e}')
                return False

            if not resp_event.wait(self.GOAL_SEND_TIMEOUT_S):
                self.get_logger().error(f'[{tag}] Timeout waiting for goal ACCEPT (attempt {attempt}).')
                if attempt <= self.ACCEPT_RETRIES:
                    time.sleep(self.ACCEPT_RETRY_BACKOFF_S)
                continue

            if not store['accepted']:
                if attempt <= self.ACCEPT_RETRIES:
                    time.sleep(self.ACCEPT_RETRY_BACKOFF_S)
                    continue
                return False

            # Wait for execution result
            if not done_event.wait(self.GOAL_RESULT_TIMEOUT_S):
                self.get_logger().error(f'[{tag}] Timeout waiting for result; canceling…')
                try:
                    store_handle = store.get('handle')
                    if store_handle:
                        cancel_fut = store_handle.cancel_goal_async()
                        # no blocking wait; executor will process cancel
                except Exception:
                    pass
                return False

            status = store['status']
            self.get_logger().info(f'[{tag}] MoveGroup status={status} (4=SUCCEEDED).')
            if status != 4:
                try:
                    ec_obj = getattr(getattr(store['result'], "result", None), "error_code", None)
                    ec_val = getattr(ec_obj, "val", None)
                    if ec_val is not None:
                        self.get_logger().warn(f'[{tag}] Planner error_code={ec_val}')
                except Exception:
                    pass
            return True

        return False


def main(args=None):
    rclpy.init(args=args)
    node = HSPickCarry()
    from rclpy.executors import MultiThreadedExecutor
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        node.get_logger().info('Shutting down.')
    finally:
        executor.shutdown()
        node.destroy_node()
        # --- FIX 2: only shutdown if context still OK (avoid double shutdown error) ---
        try:
            if rclpy.ok():
                rclpy.shutdown()
        except Exception:
            pass
        # ------------------------------------------------------------------------------


if __name__ == '__main__':
    main()

